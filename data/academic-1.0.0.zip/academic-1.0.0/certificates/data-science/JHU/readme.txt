Data Science Specialization
— Johns Hopkins University, https://www.jhu.edu/, Baltimore, MD, USA.
  —— [A] The Data Scientist’s Toolbox, 5XUVN2V5BG
  —— [B] R Programming, RZX336WBS7
  —— [C] Getting and Cleaning Data, S3RUNF7MLH
  —— [D] Exploratory Data Analysis, DQSP9UK4L9
  —— [E] Reproducible Research, ZVHSACWLP3
  —— [F] Statistical Inference, 95V5YH58Z6
  —— [G] Regression Models, M6W4YAZGVE
  —— [H] Practical Machine Learning, 9ZW3JDPAWJ
  —— [I] Developing Data Products, ZNBNLLFD3G
  —— [J] Data Science Capstone, 4JCD5D82HNFM
