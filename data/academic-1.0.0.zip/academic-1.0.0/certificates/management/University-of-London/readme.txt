Brand Management
— London Business School, University of London, http://www.london.edu/, London, England.
  —— [A] Brand Management, 8JKZL4ZUKR.
