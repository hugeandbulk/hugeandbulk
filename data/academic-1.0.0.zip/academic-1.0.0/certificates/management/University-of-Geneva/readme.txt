Organizations Management
— University of Geneva, http://www.unige.ch/, Geneva, Switzerland.
  —— [A] International Organizations Management, 54KM3WKDU4.
