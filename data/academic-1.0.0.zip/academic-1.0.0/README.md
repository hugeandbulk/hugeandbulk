# Academic [![Apache License](https://img.shields.io/badge/license-MIT-blue.svg)](https://github.com/iamprabhat/academic/blob/master/LICENSE)
Academics of [Prabhat Kumar](http://prabhatkumar.org/) — CEO, Founder & Scientist.
<br/><br/><kbd>t</kbd>&nbsp;<kbd>esc</kbd><br/><br/>
<b>Many Thanks</b> to [GitHub](https://github.com/) 💋 `~/`
